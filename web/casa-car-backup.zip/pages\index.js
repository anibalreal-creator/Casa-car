import Link from 'next/link';

export default function Home() {
  return (
    <main style={{ maxWidth: 600, margin: '40px auto', fontFamily: 'serif' }}>
      <h1>Inicio</h1>

      <p>Últimos anuncios publicados:</p>

      <ul>
        <li>🟢 Anuncio de prueba (por ahora)</li>
        <li>🟢 Próximamente se listan desde Supabase</li>
      </ul>

      <hr />

      <p>
        <Link href="/publicar">Publicar anuncio</Link>
        {' | '}
        <Link href="/dashboard">Dashboard</Link>
      </p>
    </main>
  );
}
