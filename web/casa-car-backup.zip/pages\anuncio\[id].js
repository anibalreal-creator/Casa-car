import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";

export default function Detalle() {
  const router = useRouter();
  const { id } = router.query;
  const [anuncio, setAnuncio] = useState(null);

  useEffect(() => {
    if (!id) return;

    supabase
      .from("anuncios")
      .select("*")
      .eq("id", id)
      .single()
      .then(({ data }) => setAnuncio(data));
  }, [id]);

  if (!anuncio) return <p>Cargando…</p>;

  return (
    <div style={{ padding: 20 }}>
      <button onClick={() => router.back()}>← Volver</button>

      <h1>{anuncio.titulo}</h1>

      <p>
        <b>{anuncio.operacion.toUpperCase()}</b> — {anuncio.tipo} —{" "}
        {anuncio.ciudad}
      </p>

      <h2>
        {anuncio.moneda === "USD" && "US$ "}
        {anuncio.moneda === "ARS" && "$ "}
        {anuncio.moneda === "BRL" && "R$ "}
        {anuncio.precio.toLocaleString()}
      </h2>

      <p>{anuncio.descripcion}</p>

      <small>ID: {anuncio.id}</small>
    </div>
  );
}
