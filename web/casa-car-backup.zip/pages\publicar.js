// pages/publicar.js
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import { supabase } from "../lib/supabaseClient";

export default function Publicar() {
  const router = useRouter();

  const [session, setSession] = useState(null);
  const [loadingSession, setLoadingSession] = useState(true);

  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");

  // Guardamos las fotos como objetos { file, id, previewUrl }
  const [files, setFiles] = useState([]);

  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  const user = session?.user ?? null;

  // =========================
  // 1) Sesión
  // =========================
  useEffect(() => {
    let mounted = true;

    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (!mounted) return;
        setSession(data.session ?? null);
        setLoadingSession(false);
      })
      .catch(() => {
        if (!mounted) return;
        setSession(null);
        setLoadingSession(false);
      });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });

    return () => {
      mounted = false;
      sub?.subscription?.unsubscribe?.();
    };
  }, []);

  // Limpia mensajes al entrar (más profesional)
  useEffect(() => {
    setMsg("");
    setErr("");
  }, []);

  // Mensajes se borran solos (para que no queden pegados)
  useEffect(() => {
    if (!msg) return;
    const t = setTimeout(() => setMsg(""), 4000);
    return () => clearTimeout(t);
  }, [msg]);

  useEffect(() => {
    if (!err) return;
    const t = setTimeout(() => setErr(""), 6000);
    return () => clearTimeout(t);
  }, [err]);

  // =========================
  // 2) Helpers UI (profesional)
  // =========================
  const canPublish = useMemo(() => {
    const p = Number(String(price).replace(",", "."));
    return title.trim().length > 1 && Number.isFinite(p) && p > 0 && files.length > 0 && !!user;
  }, [title, price, files.length, user]);

  function clearFeedback() {
    if (msg) setMsg("");
    if (err) setErr("");
  }

  function onChangeTitle(v) {
    clearFeedback();
    setTitle(v);
  }
  function onChangePrice(v) {
    clearFeedback();
    setPrice(v);
  }

  // =========================
  // 3) Fotos: agregar / borrar una / borrar todas
  // =========================
  function addFilesFromInput(fileList) {
    clearFeedback();
    const arr = Array.from(fileList || []);
    if (arr.length === 0) return;

    const newOnes = arr.map((f) => ({
      file: f,
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      previewUrl: URL.createObjectURL(f),
    }));

    setFiles((prev) => [...prev, ...newOnes]);
  }

  function removeOneFile(id) {
    clearFeedback();
    setFiles((prev) => {
      const toRemove = prev.find((x) => x.id === id);
      if (toRemove?.previewUrl) URL.revokeObjectURL(toRemove.previewUrl);
      return prev.filter((x) => x.id !== id);
    });
  }

  function removeAllFiles() {
    clearFeedback();
    setFiles((prev) => {
      prev.forEach((x) => x.previewUrl && URL.revokeObjectURL(x.previewUrl));
      return [];
    });
  }

  // Limpieza de previews al desmontar
  useEffect(() => {
    return () => {
      files.forEach((x) => x.previewUrl && URL.revokeObjectURL(x.previewUrl));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // =========================
  // 4) Subida a Storage + Insert en DB
  // =========================
  async function uploadToStorageAndGetPublicUrl(fileObj) {
    // Guardamos en: listings/<userId>/<timestamp>-<filename>
    const safeName = fileObj.file.name.replace(/[^\w.\-]+/g, "_");
    const path = `${user.id}/${Date.now()}-${safeName}`;

    const { error: upErr } = await supabase.storage
      .from("listings")
      .upload(path, fileObj.file, {
        cacheControl: "3600",
        upsert: false,
        contentType: fileObj.file.type || "application/octet-stream",
      });

    if (upErr) throw upErr;

    const { data } = supabase.storage.from("listings").getPublicUrl(path);

    // data.publicUrl
    return data?.publicUrl || null;
  }

  async function onPublish(e) {
    e.preventDefault();
    clearFeedback();

    if (!user) {
      setErr("Tenés que iniciar sesión para publicar.");
      return;
    }
    if (files.length === 0) {
      setErr("Elegí al menos 1 foto.");
      return;
    }
    const p = Number(String(price).replace(",", "."));
    if (!title.trim() || !Number.isFinite(p) || p <= 0) {
      setErr("Completá Título y Precio válido.");
      return;
    }

    setSaving(true);

    try {
      // 1) Subir fotos
      const urls = [];
      for (const f of files) {
        const u = await uploadToStorageAndGetPublicUrl(f);
        if (!u) throw new Error("No se pudo obtener la URL pública de una foto.");
        urls.push(u);
      }

      // 2) Insert en tabla public.listings
      const payload = {
        user_id: user.id,
        title: title.trim(),
        price: p,
        photos: urls, // jsonb (array)
      };

      const { error: insErr } = await supabase.from("listings").insert(payload);
      if (insErr) throw insErr;

      setMsg('✅ Anuncio publicado. Volvé al inicio para verlo en "Últimos anuncios".');
      setTitle("");
      setPrice("");
      removeAllFiles();
    } catch (e2) {
      const msg2 =
        e2?.message ||
        e2?.error_description ||
        "Error publicando. Revisá permisos RLS / Storage policies.";
      setErr(`❌ ${msg2}`);
    } finally {
      setSaving(false);
    }
  }

  // =========================
  // 5) Render
  // =========================
  if (loadingSession) {
    return (
      <main style={styles.main}>
        <div style={styles.card}>
          <h1 style={styles.h1}>Publicar anuncio</h1>
          <p>Cargando sesión…</p>
        </div>
      </main>
    );
  }

  if (!user) {
    return (
      <main style={styles.main}>
        <div style={styles.card}>
          <h1 style={styles.h1}>Publicar anuncio</h1>
          <p style={{ marginTop: 8 }}>
            Tenés que iniciar sesión para publicar.
          </p>
          <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
            <button style={styles.btn} onClick={() => router.push("/login")}>
              Ir a login
            </button>
            <button style={styles.btnGhost} onClick={() => router.push("/")}>
              Volver al inicio
            </button>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main style={styles.main}>
      <div style={styles.card}>
        <h1 style={styles.h1}>Publicar anuncio</h1>
        <p style={styles.subtitle}>
          En producción: sube fotos reales y cobra publicación.
        </p>

        <div style={styles.links}>
          <a href="/" style={styles.link}>Inicio</a>
          <span style={{ opacity: 0.5 }}>|</span>
          <a href="/dashboard" style={styles.link}>Dashboard</a>
        </div>

        <form onSubmit={onPublish} style={{ marginTop: 14 }}>
          <label style={styles.label}>Título</label>
          <input
            style={styles.input}
            value={title}
            onChange={(e) => onChangeTitle(e.target.value)}
            placeholder="Ej: Depto 2 ambientes"
            disabled={saving}
          />

          <label style={styles.label}>Precio</label>
          <input
            style={styles.input}
            value={price}
            onChange={(e) => onChangePrice(e.target.value)}
            placeholder="Ej: 30000"
            disabled={saving}
            inputMode="decimal"
          />

          <label style={styles.label}>Fotos</label>

          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => addFilesFromInput(e.target.files)}
              disabled={saving}
            />

            <button
              type="button"
              style={styles.btnDangerGhost}
              onClick={removeAllFiles}
              disabled={saving || files.length === 0}
              title="Quitar todas las fotos"
            >
              Quitar todas
            </button>

            <span style={{ fontSize: 13, opacity: 0.8 }}>
              {files.length > 0 ? `${files.length} archivo(s) seleccionado(s)` : "Sin fotos"}
            </span>
          </div>

          {files.length > 0 && (
            <div style={styles.previewWrap}>
              {files.map((f) => (
                <div key={f.id} style={styles.previewItem}>
                  <button
                    type="button"
                    onClick={() => removeOneFile(f.id)}
                    style={styles.removeOne}
                    title="Quitar esta foto"
                    disabled={saving}
                  >
                    ✕
                  </button>
                  {/* preview */}
                  <img
                    src={f.previewUrl}
                    alt="preview"
                    style={styles.previewImg}
                  />
                  <div style={styles.previewName} title={f.file.name}>
                    {f.file.name}
                  </div>
                </div>
              ))}
            </div>
          )}

          <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
            <button
              type="submit"
              style={canPublish && !saving ? styles.btn : styles.btnDisabled}
              disabled={!canPublish || saving}
            >
              {saving ? "Publicando…" : "Publicar"}
            </button>

            <button
              type="button"
              style={styles.btnGhost}
              onClick={() => {
                clearFeedback();
                setTitle("");
                setPrice("");
                removeAllFiles();
              }}
              disabled={saving}
            >
              Limpiar formulario
            </button>
          </div>

          {msg && (
            <div style={styles.okBox}>
              {msg}
            </div>
          )}

          {err && (
            <div style={styles.errBox}>
              {err}
            </div>
          )}
        </form>
      </div>
    </main>
  );
}

// ======== estilos inline simples y prolijos ========
const styles = {
  main: {
    minHeight: "100vh",
    display: "grid",
    placeItems: "start center",
    padding: "28px 12px",
    fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial",
    background: "#fafafa",
  },
  card: {
    width: "min(760px, 100%)",
    background: "white",
    border: "1px solid #e7e7e7",
    borderRadius: 10,
    padding: 18,
    boxShadow: "0 6px 18px rgba(0,0,0,0.04)",
  },
  h1: { margin: 0, fontSize: 28, lineHeight: 1.2 },
  subtitle: { marginTop: 8, marginBottom: 6, opacity: 0.75 },
  links: { display: "flex", gap: 10, alignItems: "center", marginTop: 6 },
  link: { color: "#2563eb", textDecoration: "none" },
  label: { display: "block", marginTop: 12, marginBottom: 6, fontWeight: 600 },
  input: {
    width: "100%",
    padding: "10px 12px",
    borderRadius: 8,
    border: "1px solid #d6d6d6",
    outline: "none",
  },
  btn: {
    padding: "10px 14px",
    borderRadius: 8,
    border: "1px solid #111827",
    background: "#111827",
    color: "white",
    cursor: "pointer",
  },
  btnDisabled: {
    padding: "10px 14px",
    borderRadius: 8,
    border: "1px solid #cfcfcf",
    background: "#eaeaea",
    color: "#6b7280",
    cursor: "not-allowed",
  },
  btnGhost: {
    padding: "10px 14px",
    borderRadius: 8,
    border: "1px solid #d1d5db",
    background: "white",
    cursor: "pointer",
  },
  btnDangerGhost: {
    padding: "8px 12px",
    borderRadius: 8,
    border: "1px solid #ef4444",
    background: "white",
    color: "#ef4444",
    cursor: "pointer",
  },
  okBox: {
    marginTop: 12,
    padding: "10px 12px",
    borderRadius: 8,
    background: "#ecfdf5",
    border: "1px solid #10b981",
    color: "#065f46",
    fontWeight: 600,
  },
  errBox: {
    marginTop: 12,
    padding: "10px 12px",
    borderRadius: 8,
    background: "#fef2f2",
    border: "1px solid #ef4444",
    color: "#991b1b",
    fontWeight: 600,
    whiteSpace: "pre-wrap",
  },
  previewWrap: {
    marginTop: 12,
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
    gap: 12,
  },
  previewItem: {
    position: "relative",
    border: "1px solid #e5e7eb",
    borderRadius: 10,
    overflow: "hidden",
    background: "#fff",
  },
  previewImg: {
    width: "100%",
    height: 130,
    objectFit: "cover",
    display: "block",
  },
  previewName: {
    padding: "8px 10px",
    fontSize: 12,
    opacity: 0.8,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  removeOne: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 28,
    height: 28,
    borderRadius: 999,
    border: "1px solid rgba(0,0,0,0.12)",
    background: "rgba(255,255,255,0.92)",
    cursor: "pointer",
    fontWeight: 700,
  },
};
